/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-135db600'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "placeholder.svg",
    "revision": "35707bd9960ba5281c72af927b79291f"
  }, {
    "url": "index.html",
    "revision": "83af43654b27bcc64edc5c395ea644ea"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "assets/workHoursTracker-fNYfLEcE.js",
    "revision": null
  }, {
    "url": "assets/wallet-Dn1lo0sg.js",
    "revision": null
  }, {
    "url": "assets/vendor-ui-DQrUE-Jh.js",
    "revision": null
  }, {
    "url": "assets/vendor-supabase-D_t8kiev.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-B2AhFMKx.js",
    "revision": null
  }, {
    "url": "assets/users-Ddh-mH4B.js",
    "revision": null
  }, {
    "url": "assets/user-check-D-Gnt9c5.js",
    "revision": null
  }, {
    "url": "assets/triangle-alert-C2hI7-Lm.js",
    "revision": null
  }, {
    "url": "assets/sliders-horizontal-CO0Qrhc3.js",
    "revision": null
  }, {
    "url": "assets/send-owTElWvD.js",
    "revision": null
  }, {
    "url": "assets/save-DdPupS4T.js",
    "revision": null
  }, {
    "url": "assets/receipt-Cs33RsbC.js",
    "revision": null
  }, {
    "url": "assets/priceAnomaly-BRr1tbxR.js",
    "revision": null
  }, {
    "url": "assets/pencil-BS5Om3er.js",
    "revision": null
  }, {
    "url": "assets/partsStore-CcRBqlYh.js",
    "revision": null
  }, {
    "url": "assets/package-CePk5_zo.js",
    "revision": null
  }, {
    "url": "assets/layers-j4T1gN_2.js",
    "revision": null
  }, {
    "url": "assets/info-CRXh-fcc.js",
    "revision": null
  }, {
    "url": "assets/index-BzMeOl7o.js",
    "revision": null
  }, {
    "url": "assets/index-BDGyQXUp.css",
    "revision": null
  }, {
    "url": "assets/history-CB2uRc6f.js",
    "revision": null
  }, {
    "url": "assets/filter-BaPYKxWu.js",
    "revision": null
  }, {
    "url": "assets/file-spreadsheet-BYwfTocB.js",
    "revision": null
  }, {
    "url": "assets/external-link-BSXDGlZo.js",
    "revision": null
  }, {
    "url": "assets/exportUtils-Dy_8ywHm.js",
    "revision": null
  }, {
    "url": "assets/database-backup-CMV_Kwi1.js",
    "revision": null
  }, {
    "url": "assets/database-D4CusCrC.js",
    "revision": null
  }, {
    "url": "assets/cloud-upload-DHHioIGA.js",
    "revision": null
  }, {
    "url": "assets/clock-3-CRY6faFc.js",
    "revision": null
  }, {
    "url": "assets/clipboard-check-DqRnVGAc.js",
    "revision": null
  }, {
    "url": "assets/circle-x-E5ySYXC6.js",
    "revision": null
  }, {
    "url": "assets/calendar-days-CLZeOz1I.js",
    "revision": null
  }, {
    "url": "assets/calendar-DBZgJCi_.js",
    "revision": null
  }, {
    "url": "assets/bell-CsGg9aDf.js",
    "revision": null
  }, {
    "url": "assets/ban-BvGrEtR_.js",
    "revision": null
  }, {
    "url": "assets/arrow-right-DhcK25tL.js",
    "revision": null
  }, {
    "url": "assets/activity-C5hHvXpR.js",
    "revision": null
  }, {
    "url": "assets/ZonesPage-DFOMj5av.js",
    "revision": null
  }, {
    "url": "assets/TriangleKeyLocationsPage-DkSqJSgE.js",
    "revision": null
  }, {
    "url": "assets/TechnicianMobileApp-BbDPyod-.js",
    "revision": null
  }, {
    "url": "assets/TechnicianDashboard-CQbmU6mg.js",
    "revision": null
  }, {
    "url": "assets/SystemHealthPage-dJPXg5kB.js",
    "revision": null
  }, {
    "url": "assets/StaffPage-BOR_VzJg.js",
    "revision": null
  }, {
    "url": "assets/SmartAssistantPage-NCJENTSk.js",
    "revision": null
  }, {
    "url": "assets/ServiceForm-Cxd9TSq8.js",
    "revision": null
  }, {
    "url": "assets/ScheduleManagementPage-B2n6B_hw.js",
    "revision": null
  }, {
    "url": "assets/PartsPage-BRiaRvAD.js",
    "revision": null
  }, {
    "url": "assets/OperationalReadinessPage-CPxjd3yA.js",
    "revision": null
  }, {
    "url": "assets/NumberStepper-Cn6mswEL.js",
    "revision": null
  }, {
    "url": "assets/NotificationsPanel-C7_Kf4ZN.js",
    "revision": null
  }, {
    "url": "assets/MarketingFlyout-CUZa88qX.js",
    "revision": null
  }, {
    "url": "assets/IncompleteDataCenter-VILb-ARH.js",
    "revision": null
  }, {
    "url": "assets/DataIntegrityPage-Cxg_s1x1.js",
    "revision": null
  }, {
    "url": "assets/CustomersPage-BxJk03aA.js",
    "revision": null
  }, {
    "url": "assets/CustomerReportsPage-CxwG-Xp_.js",
    "revision": null
  }, {
    "url": "assets/CustomerPortalView-9btR46ud.js",
    "revision": null
  }, {
    "url": "assets/CsvUploadPage-B4gEcPZt.js",
    "revision": null
  }, {
    "url": "assets/CpanelSettingsPage-JPBWinOu.js",
    "revision": null
  }, {
    "url": "assets/ContractsPage-DTHAvVz0.js",
    "revision": null
  }, {
    "url": "assets/ContractView-brnMy3_D.js",
    "revision": null
  }, {
    "url": "assets/ChecklistSettingsPage-B1jLQJDz.js",
    "revision": null
  }, {
    "url": "assets/AuditHistoryPage-BKMKgQ_v.js",
    "revision": null
  }, {
    "url": "assets/AdminQuickServiceCompletionPage-C_7_mWmM.js",
    "revision": null
  }, {
    "url": "assets/AccessManagementPage-Bnm29rKq.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1f1216864a5c781887515c844f834ec2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(({
    url
  }) => /\/assets\/xlsx-.*\.js$/i.test(url.pathname), new workbox.StaleWhileRevalidate({
    "cacheName": "tlift-excel-on-demand-v1",
    plugins: [new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.includes("/uploads/") || /\.(?:jpg|jpeg|png|webp)$/i.test(url.pathname), new workbox.CacheFirst({
    "cacheName": "tlift-photos-v1",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 180,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.endsWith("/api/sync.php") || url.pathname.endsWith("/sync.php"), new workbox.NetworkOnly(), 'GET');

}));
