/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-135db600'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "placeholder.svg",
    "revision": "35707bd9960ba5281c72af927b79291f"
  }, {
    "url": "index.html",
    "revision": "25f5a1c339a892afdeb7097749d1a945"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "assets/workHoursTracker-fNYfLEcE.js",
    "revision": null
  }, {
    "url": "assets/wallet-DIhuysG5.js",
    "revision": null
  }, {
    "url": "assets/vendor-ui-DQrUE-Jh.js",
    "revision": null
  }, {
    "url": "assets/vendor-supabase-D_t8kiev.js",
    "revision": null
  }, {
    "url": "assets/vendor-react-B2AhFMKx.js",
    "revision": null
  }, {
    "url": "assets/users-CfGzTMdi.js",
    "revision": null
  }, {
    "url": "assets/user-check-CpnOeNVm.js",
    "revision": null
  }, {
    "url": "assets/triangle-alert-CB_9xV6h.js",
    "revision": null
  }, {
    "url": "assets/sliders-horizontal-o8RpgjMN.js",
    "revision": null
  }, {
    "url": "assets/send-CquQU9uf.js",
    "revision": null
  }, {
    "url": "assets/save-DmpPOKJ_.js",
    "revision": null
  }, {
    "url": "assets/receipt-D3xfZqoc.js",
    "revision": null
  }, {
    "url": "assets/priceAnomaly-BRr1tbxR.js",
    "revision": null
  }, {
    "url": "assets/pencil-SfKGJWc5.js",
    "revision": null
  }, {
    "url": "assets/partsStore-CuErmwcd.js",
    "revision": null
  }, {
    "url": "assets/package-BUF80qed.js",
    "revision": null
  }, {
    "url": "assets/layers-B_b_fKMw.js",
    "revision": null
  }, {
    "url": "assets/info-Dg5-JmLJ.js",
    "revision": null
  }, {
    "url": "assets/index-DuUirv-U.css",
    "revision": null
  }, {
    "url": "assets/index-BiinZA6P.js",
    "revision": null
  }, {
    "url": "assets/history-DckgJyFi.js",
    "revision": null
  }, {
    "url": "assets/filter-TKjR3FiF.js",
    "revision": null
  }, {
    "url": "assets/file-spreadsheet-C0zmQMkT.js",
    "revision": null
  }, {
    "url": "assets/external-link-BKqPE9jN.js",
    "revision": null
  }, {
    "url": "assets/exportUtils-Dr5Lyq7O.js",
    "revision": null
  }, {
    "url": "assets/database-backup-O_NPWbB1.js",
    "revision": null
  }, {
    "url": "assets/database-DPW-B2GJ.js",
    "revision": null
  }, {
    "url": "assets/cloud-upload-loGNXAsW.js",
    "revision": null
  }, {
    "url": "assets/clock-3-3AP9lpbx.js",
    "revision": null
  }, {
    "url": "assets/clipboard-check-B7zX-A6F.js",
    "revision": null
  }, {
    "url": "assets/circle-x-5wkQup5C.js",
    "revision": null
  }, {
    "url": "assets/calendar-esFf_UOd.js",
    "revision": null
  }, {
    "url": "assets/calendar-days-Db7knISs.js",
    "revision": null
  }, {
    "url": "assets/bell-E7Wl8csh.js",
    "revision": null
  }, {
    "url": "assets/ban-B7g93iHk.js",
    "revision": null
  }, {
    "url": "assets/arrow-right-JcRPNrdU.js",
    "revision": null
  }, {
    "url": "assets/activity-Bo9ZvmAv.js",
    "revision": null
  }, {
    "url": "assets/ZonesPage-DnyrtvDv.js",
    "revision": null
  }, {
    "url": "assets/TriangleKeyLocationsPage-By9VTUga.js",
    "revision": null
  }, {
    "url": "assets/TechnicianMobileApp-CeNwECWj.js",
    "revision": null
  }, {
    "url": "assets/TechnicianDashboard-DGq4GYMc.js",
    "revision": null
  }, {
    "url": "assets/SystemHealthPage-m94PKqD3.js",
    "revision": null
  }, {
    "url": "assets/StaffPage-u1YUsu_N.js",
    "revision": null
  }, {
    "url": "assets/SmartAssistantPage-BMuv68SF.js",
    "revision": null
  }, {
    "url": "assets/ServiceForm-mLR80WRh.js",
    "revision": null
  }, {
    "url": "assets/ScheduleManagementPage-B9YDxLSp.js",
    "revision": null
  }, {
    "url": "assets/PartsPage-BYXWwghJ.js",
    "revision": null
  }, {
    "url": "assets/OperationalReadinessPage-HYOpwyJz.js",
    "revision": null
  }, {
    "url": "assets/NumberStepper-BtrsJ0aF.js",
    "revision": null
  }, {
    "url": "assets/NotificationsPanel-BoJIylQn.js",
    "revision": null
  }, {
    "url": "assets/MarketingFlyout-C3Y7EAOB.js",
    "revision": null
  }, {
    "url": "assets/IncompleteDataCenter-C4FwVx0q.js",
    "revision": null
  }, {
    "url": "assets/DataIntegrityPage-CQw82Fa_.js",
    "revision": null
  }, {
    "url": "assets/CustomersPage-ChuAtu8r.js",
    "revision": null
  }, {
    "url": "assets/CustomerReportsPage-Kpd46bIv.js",
    "revision": null
  }, {
    "url": "assets/CustomerPortalView-BxcDmp34.js",
    "revision": null
  }, {
    "url": "assets/CsvUploadPage-CP3mJ1sg.js",
    "revision": null
  }, {
    "url": "assets/CpanelSettingsPage-D4BMiuKF.js",
    "revision": null
  }, {
    "url": "assets/ContractsPage-Dj7ttDXS.js",
    "revision": null
  }, {
    "url": "assets/ContractView-EyxjAF6h.js",
    "revision": null
  }, {
    "url": "assets/ChecklistSettingsPage-DI8SPJiN.js",
    "revision": null
  }, {
    "url": "assets/AuditHistoryPage-CdoBVbFd.js",
    "revision": null
  }, {
    "url": "assets/AdminQuickServiceCompletionPage-C-r83hAV.js",
    "revision": null
  }, {
    "url": "assets/AccessManagementPage-CgSEvKaO.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "favicon.ico",
    "revision": "574a19b6745bdb5515ca6dcff63d29af"
  }, {
    "url": "pwa-192x192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "icons/icon-192.png",
    "revision": "47cf30658878bf189016f18a0389327d"
  }, {
    "url": "icons/icon-512.png",
    "revision": "31e97947fb73fdf04b759d810db61802"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1f1216864a5c781887515c844f834ec2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(({
    url
  }) => /\/assets\/xlsx-.*\.js$/i.test(url.pathname), new workbox.StaleWhileRevalidate({
    "cacheName": "tlift-excel-on-demand-v1",
    plugins: [new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.includes("/uploads/") || /\.(?:jpg|jpeg|png|webp)$/i.test(url.pathname), new workbox.CacheFirst({
    "cacheName": "tlift-photos-v1",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 180,
      maxAgeSeconds: 2592000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(({
    url
  }) => url.pathname.endsWith("/api/sync.php") || url.pathname.endsWith("/sync.php"), new workbox.NetworkOnly(), 'GET');

}));
